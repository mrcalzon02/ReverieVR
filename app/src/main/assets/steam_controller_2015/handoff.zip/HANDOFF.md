# ReverieVR original Steam Controller handoff

Copyright 2016 Valve Corporation. Modified render assets: exact welding,
QEM simplification and explicitly recorded voxel surface approximations.
Assets are CC BY-NC-SA 4.0. Preserve LICENSE.TXT and PROVENANCE.json when
sharing. Commercial use needs permission from Valve. No Valve endorsement.

Start with controller.glb: named parts, meters, +X right, +Y up, -Z forward.
assembled.obj uses the same meter coordinates and can open in ReverieVR's
existing OBJ viewer. Individual OBJ files retain original source mm coordinates;
use (x,y,z) -> (x,z,-y)*0.001 exactly once. Do not recenter parts independently.
Colors identify parts only. Source file assemblies remain single named parts;
actual hinge pivots still require mechanical/visual review.

conversion_manifest.json records all source/output hashes, part budgets,
bounds, repair resolutions and topology flags. VALIDATION.json records
completed checks and remaining gates. These are render approximations;
seven parts retain boundary/nonmanifold flags. Do not treat them as watertight
manufacturing CAD or validated collision volumes. Prefer primitive colliders.
Tiny details, round openings, lettering and internal cavities may change.

controller.rvmesh is directly packable for GLES2: little-endian magic
RVSC0001 (8 bytes), uint32 part count; per part uint32 name length, uint32
vertex count, ASCII name, then six float32 per vertex (position XYZ, normal
XYZ). Consecutive vertex triples are triangles. Suggested one static VBO,
24-byte stride, position offset 0 / normal offset 12, with named draw ranges.
Keep the source-license/manifest alongside optional runtime assets. Re-upload
on GL context recreation, release GL objects, and preserve shell GL state.

Programming/hookup belongs to the next online instance: work on
mrcalzon02/ReverieVR main, read AGENTS.md and project execution doctrine,
integrate through the existing controller visualization architecture and
document/test the change. No APK or integrated Steam renderer was built here.
No physical Android part mappings are provided: right-pad mouse movement and
an unspecified trigger click are user observations, not exact event reports.
Capture Android device/key/axis/button reports before physical-part mappings.
Do not fabricate gyro, dual-pad, grip or trigger-side support. Test Galaxy S9
stereo, lifecycle/recovery, event visualization and sustained performance.

Original ZIP and CAD are preserved locally and are deliberately excluded from
this compact handoff; the authoritative source URL and SHA256 are in PROVENANCE.
Reproducible pipeline source and dependency pins are included under pipeline/.
SHA256SUMS covers each packaged file except the checksum list itself.
